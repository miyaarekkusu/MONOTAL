﻿# ユーザーアカウント初期化機能

## Context
展覧会でMONOTALの各機能を最初からデモするために、特定ユーザーのアカウントを初期状態（登録直後）に戻す管理者機能が必要。ユーザーのステータスを`未認証ユーザー(1)`に戻し、そのユーザーIDを参照する全テーブルのレコードを削除する。

## 変更対象ファイル

| ファイル | 操作 |
|---------|------|
| `admin_panel/views.py` | ビュー2つ追加（一覧+実行） |
| `admin_panel/urls.py` | URLパターン2つ追加 |
| `admin_panel/templates/admin_panel/user_reset.html` | 新規作成 |
| `admin_panel/templates/admin_panel/dashboard.html` | カードリンク追加 |

## 実装詳細

### 1. URL設計
```
GET  /admin-panel/user-reset/              → ユーザー一覧（検索付き）
POST /admin-panel/user-reset/<user_id>/    → 初期化実行（Ajax）
```

### 2. ビュー（admin_panel/views.py）

**一覧ページ** `admin_user_reset_list`
- `@login_required` + `is_staff` チェック（既存パターン踏襲）
- GETパラメータ `q` でユーザー名/表示名を部分一致検索
- 各ユーザーの関連レコード件数をカウントして表示

**初期化実行** `admin_user_reset_execute`
- POST + Ajax（`X-Requested-With: XMLHttpRequest`）
- `transaction.atomic()` でトランザクション保護
- JsonResponseで結果返却

### 3. 削除対象と順序（FK制約を考慮）

```
① 通知系:        NotificationRead, NotificationTargetUser
② チャット系:    MessageRead, Message, ChatRoomParticipant, CommunityMember
                  Community → creator を NULL に更新
③ Q&A:          QAAnswer, QAQuestion
④ クエスト/クーポン: UserCompletedQuest, UserCoupon
⑤ 通報/違反:    Report, ViolationHistory
⑥ レンタル系:   CancellationRequest → UserReview → RentalRequestRead
                  → RentalHistory → RentalRequest（PROTECT対策で先に削除）
⑦ 金融系:       InsuranceClaim, InsuranceEnrollment, CreditCard, BankAccount, PaymentInfo
⑧ ソーシャル:   Follow, ListingNotification, Block
⑨ 閲覧系:       Bookmark, BrowsingHistory
⑩ 商品:         Product（→ ProductImage, ProductRentalPlan 等がCASCADE削除）
⑪ 個人情報:     IdentityVerification, UserHobby, UserAddress, UserPersonalInfo
```

### 4. ユーザーフィールドのリセット
```
user_status_id    → 1（未認証ユーザー）
user_image        → None
bio               → ''
login_attempt_count → 0
```
※ user_name, display_name, email, phone_number, password は維持（ログイン可能状態を保持）

### 5. UI設計

**ダッシュボード**: 既存カードと同じパターンで「アカウント初期化」カード追加（icon: `lucide:rotate-ccw`）

**一覧ページ**:
- 検索バー（ユーザー名/表示名で絞り込み）
- テーブル: No. / ユーザー名 / 表示名 / ステータス / 登録日 / 操作
- 「初期化」ボタン → base.html の既存モーダルで確認 → Ajax POST → 成功時ページリロード

## 検証方法
1. `/admin-panel/` にアクセスし「アカウント初期化」カードが表示されること
2. ユーザー検索で対象ユーザーを見つけられること
3. 初期化実行後、対象ユーザーの関連データが全削除されること
4. ユーザーのステータスが「未認証ユーザー」に戻っていること
5. ユーザーが引き続きログイン可能であること
