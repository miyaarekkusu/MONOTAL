﻿# マイページに「コミュニティ」タブを追加

## Context
マイページのサイドバーに「コミュニティ」項目を追加し、自分が所属しているグループと自分のQ&A質問を一覧表示するページを作成する。Q&Aには「すべて/受付中/終了済み」の切り替えフィルターを付ける。各項目クリックで詳細ページへ遷移する。

## 変更対象ファイル（4箇所）

### 1. `appfew/templates/mypage/_sidebar.html` — サイドバーに項目追加
「趣味登録」の直後（L102付近）に「コミュニティ」リンクを追加。
- `current_page == 'community'` でアクティブ判定
- アイコン: `lucide:messages-square`
- 既存パターンに完全準拠（active/inactive分岐）

### 2. `appfew/monotal/views.py` — ビュー追加
`MyPageCommunityView(LoginRequiredMixin, View)` を新規作成。
- 所属グループ: `CommunityMember` + `Community.creator` で取得
- 自分のQ&A: `QAQuestion.objects.filter(user=request.user)`
- `status` GETパラメータで Q&A フィルタ（`open`→status_id=1, `closed`→status_id__in=[2,3]）
- context: `groups`, `questions`, `qa_status`, `current_page='community'`, `user_hobbies`
- 最後に `mypage_community = MyPageCommunityView.as_view()` の関数ショートカット

### 3. `appfew/monotal/urls.py` — URL追加
```python
path('mypage/community/', views.mypage_community, name='mypage_community'),
```
`mypage/coupons/` の近くに配置。

### 4. `appfew/templates/mypage/community.html` — テンプレート新規作成
`bookmark_list.html` のレイアウトを踏襲:
- `{% extends 'base.html' %}`, breadcrumbs, 12カラムグリッド, sidebar include
- **グループセクション**: カード形式で表示。クリック → `/monotal/community/boards/<id>/`
  - 名前・メンバー数・カテゴリを表示
- **Q&Aセクション**: カード形式で表示。クリック → `/monotal/community/qa/<id>/`
  - タイトル・ステータスバッジ(受付中/ベストアンサー/締切済)・回答数を表示
  - フィルターボタン: 「すべて」「受付中」「終了済み」（`?status=` パラメータ）
- 空状態: コミュニティページへの誘導リンク

## 検証
- `python manage.py check` でシステムチェック
- マイページサイドバーに「コミュニティ」が表示されること
- クリックで所属グループ・自分のQ&Aが表示されること
- Q&Aフィルター（すべて/受付中/終了済み）が動作すること
- グループ・Q&Aカードクリックで各詳細ページへ遷移すること
