"""
Django Models - レンタルプラットフォーム（Rental Platform）
物理モデルERから自動生成 / Gerado automaticamente do modelo físico 
テーブル総数: 45 (マスター21 + トランザクション24)

【重要な概念 / Conceitos Importantes】

1. db_table = データベースのテーブル名を明示的に指定
   例: db_table = 'T_User' → DBに正確に「T_User」というテーブルが作成される
   
2. on_delete = 外部キーで参照されているレコードが削除された時の動作
   - CASCADE: 親を削除すると子も削除（ユーザー削除 → 住所も削除）
   - PROTECT: 子が存在する場合、親の削除を防止（ステータスを使用中の商品がある場合）
   - SET_NULL: 親削除時にNULLに設定
   
3. related_name = 逆参照時の名前（user.products.all() のように使用）

4. db_column = データベースのカラム名を明示的に指定

【テーブル構成 / Organização das Tabelas】

1. ユーザー関連 (User Domain)
   - UserStatus, User, UserManager, UserAddress
   - IdentityVerificationStatus, IdentityVerification, IdentityVerificationImage

2. ユーザー関係 (User Relationships)
   - Follow, Block, UserReview

3. 商品関連 (Product Domain)
   - ProductCategory, ProductCondition, ProductStatus, ShippingMethod
   - Product, Bookmark, BrowsingHistory

4. レンタル関連 (Rental Domain)
   - RentalStatus, RentalRequestStatus, ReturnReason
   - RentalRequest, RentalHistory, ReturnReasonHistory

5. 通報・違反関連 (Report & Violation Domain)
   - ReportReason, Report
   - ViolationReason, ViolationStatus, ViolationHistory

6. 決済・保険関連 (Payment & Insurance Domain)
   - PaymentType, PaymentInfo
   - Insurance, InsuranceEnrollmentStatus, InsuranceEnrollment

7. チャット・メッセージ関連 (Chat & Message Domain)
   - ChatRoomType, Community, ChatRoom, ChatRoomParticipant
   - Message, MessageImage, MessageReadStatus, MessageRead

8. 通知関連 (Notification Domain)
   - NotificationType, NotificationReadStatus, TargetUserType
   - Notification, NotificationRead, NotificationTargetUser
"""

import uuid
from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.utils import timezone


# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║  1. ユーザー関連 / USER DOMAIN                                                ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

class UserStatus(models.Model):
    """
    ユーザーステータスマスター
    1: 未認証ユーザー（メール認証済み、本人確認未完了）
    2: 承認済みユーザー（本人確認完了）
    3: 制限付きユーザー（違反等で制限中）
    4: 削除済みユーザー（退会済み）
    """
    user_status_id = models.AutoField(primary_key=True)
    status_name = models.CharField(max_length=50, unique=True)
    
    class Meta:
        db_table = 'M_UserStatus'
        verbose_name = 'ユーザーステータス'
        verbose_name_plural = 'ユーザーステータス'
    
    def __str__(self):
        return self.status_name


class UserManager(BaseUserManager):
    """
    ユーザーマネージャー（カスタム）
    ユーザー作成のロジックを管理
    """
    
    def create_user(self, email, user_name, display_name, phone_number, password=None, **extra_fields):
        """通常ユーザーを作成"""
        if not phone_number:
            raise ValueError('電話番号は必須です')
        email = self.normalize_email(email) if email else ''
        user = self.model(
            email=email,
            user_name=user_name,
            display_name=display_name,
            phone_number=phone_number,
            **extra_fields
        )
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, user_name, display_name, phone_number, password=None, **extra_fields):
        """スーパーユーザー（管理者）を作成"""
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        return self.create_user(email, user_name, display_name, phone_number, password, **extra_fields)


class User(AbstractBaseUser, PermissionsMixin):
    """
    ユーザーテーブル（メイン）
    
    【重要ポイント】
    - AbstractBaseUserを継承 = 認証機能を持つカスタムユーザーモデル
    - USERNAME_FIELD = 'email' = ログインにメールアドレスを使用
    - user_status への参照は on_delete=PROTECT = ステータスの削除を防止
    """
    user_id = models.AutoField(primary_key=True)
    user_name = models.CharField(max_length=100)
    display_name = models.CharField(max_length=100)
    email = models.EmailField(max_length=255)
    phone_number = models.CharField(max_length=20, default='')
    password_hash = models.CharField(max_length=255)
    login_attempt_count = models.IntegerField(default=0)
    last_login_datetime = models.DateTimeField(null=True, blank=True)
    
    user_status = models.ForeignKey(
        UserStatus,
        on_delete=models.PROTECT,
        db_column='user_status_id'
    )
    
    register_datetime = models.DateTimeField(auto_now_add=True)
    update_datetime = models.DateTimeField(auto_now=True)
    delete_datetime = models.DateTimeField(null=True, blank=True)
    
    user_image = models.ImageField(upload_to='user_images/', null=True, blank=True)
    bio = models.CharField(max_length=160, blank=True, default='')  # 自己紹介文（Twitter仕様: 160文字）

    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    
    objects = UserManager()
    
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['user_name', 'display_name']

    @property
    def id(self):
        """social-auth-djangoとの互換性のため"""
        return self.user_id

    class Meta:
        db_table = 'T_User'
        verbose_name = 'ユーザー'
        verbose_name_plural = 'ユーザー'
    
    def __str__(self):
        return f"{self.display_name} ({self.email})"


class EmailVerificationToken(models.Model):
    """
    メール認証トークンテーブル
    認証完了までユーザー登録情報を一時保存
    認証後にユーザーを作成する
    """
    token_id = models.AutoField(primary_key=True)
    token = models.UUIDField(default=uuid.uuid4, unique=True)

    # 登録情報（認証後にユーザー作成に使用）
    email = models.EmailField(max_length=255)
    user_name = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=20)
    password_hash = models.CharField(max_length=255, blank=True, default='')  # Google認証の場合は空
    is_google_auth = models.BooleanField(default=False)  # Google認証フラグ

    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()
    is_used = models.BooleanField(default=False)

    class Meta:
        db_table = 'T_EmailVerificationToken'
        verbose_name = 'メール認証トークン'
        verbose_name_plural = 'メール認証トークン'

    def is_valid(self):
        return not self.is_used and timezone.now() < self.expires_at

    def __str__(self):
        return f"{self.email} - {self.token}"


class Prefecture(models.Model):
    """
    都道府県マスターテーブル
    日本の47都道府県を管理
    """
    prefecture_id = models.AutoField(primary_key=True)
    prefecture_name = models.CharField(max_length=10, unique=True)
    prefecture_code = models.CharField(max_length=2, unique=True)  # 01-47のコード

    class Meta:
        db_table = 'M_Prefecture'
        verbose_name = '都道府県'
        verbose_name_plural = '都道府県'
        ordering = ['prefecture_id']

    def __str__(self):
        return self.prefecture_name


class UserPersonalInfo(models.Model):
    """
    ユーザー個人情報テーブル

    本人確認時に登録される個人情報
    - 氏名（姓・名）
    - 生年月日
    - 性別
    """
    user_personal_info_id = models.AutoField(primary_key=True)

    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name='personal_info',
        db_column='user_id'
    )

    last_name = models.CharField(max_length=50, verbose_name='姓')
    first_name = models.CharField(max_length=50, verbose_name='名')
    last_name_kana = models.CharField(max_length=50, null=True, blank=True, verbose_name='姓（カナ）')
    first_name_kana = models.CharField(max_length=50, null=True, blank=True, verbose_name='名（カナ）')
    birth_date = models.DateField(verbose_name='生年月日')
    gender = models.IntegerField(
        choices=[(1, '男性'), (2, '女性'), (3, 'その他')],
        verbose_name='性別'
    )
    register_datetime = models.DateTimeField(auto_now_add=True)
    update_datetime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'T_UserPersonalInfo'
        verbose_name = 'ユーザー個人情報'
        verbose_name_plural = 'ユーザー個人情報'

    def __str__(self):
        return f"{self.last_name} {self.first_name}"

    @property
    def full_name(self):
        return f"{self.last_name} {self.first_name}"

    @property
    def full_name_kana(self):
        if self.last_name_kana and self.first_name_kana:
            return f"{self.last_name_kana} {self.first_name_kana}"
        return None


class UserAddress(models.Model):
    """
    ユーザー住所テーブル

    【on_deleteの説明】
    CASCADE = ユーザーが削除されたら、その住所も自動的に削除される

    【住所構成】
    - 郵便番号: postal_code
    - 都道府県: prefecture（外部キー）
    - 市区町村・町域: city（渋谷区神南など）
    - 番地・建物名・部屋番号: street_address
    """
    user_address_id = models.AutoField(primary_key=True)

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='addresses',
        db_column='user_id'
    )

    postal_code = models.CharField(max_length=10, null=True, blank=True)
    prefecture = models.ForeignKey(
        Prefecture,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        db_column='prefecture_id'
    )
    city = models.CharField(max_length=100, null=True, blank=True)  # 市区町村・町域
    street_address = models.CharField(max_length=200, null=True, blank=True)  # 番地・建物名・部屋番号
    is_default = models.BooleanField(default=False)  # デフォルト住所フラグ
    is_deleted = models.BooleanField(default=False)  # 論理削除フラグ
    register_datetime = models.DateTimeField(auto_now_add=True)
    update_datetime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'T_UserAddress'
        verbose_name = 'ユーザー住所'
        verbose_name_plural = 'ユーザー住所'

    def __str__(self):
        return f"{self.user.display_name} - {self.postal_code}"

    def save(self, *args, **kwargs):
        # デフォルト住所として保存する場合、他の住所のデフォルトを解除
        if self.is_default:
            UserAddress.objects.filter(user=self.user, is_default=True).exclude(pk=self.pk).update(is_default=False)
        super().save(*args, **kwargs)

    @property
    def full_address(self):
        """完全な住所を返す"""
        parts = []
        if self.prefecture:
            parts.append(self.prefecture.prefecture_name)
        if self.city:
            parts.append(self.city)
        if self.street_address:
            parts.append(self.street_address)
        return ''.join(parts)


class UserHobby(models.Model):
    """
    ユーザー趣味テーブル
    ユーザーの興味のあるカテゴリを管理
    """
    user_hobby_id = models.AutoField(primary_key=True)

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='hobbies',
        db_column='user_id'
    )
    product_category = models.ForeignKey(
        'ProductCategory',
        on_delete=models.CASCADE,
        db_column='product_category_id'
    )

    register_datetime = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'T_UserHobby'
        verbose_name = 'ユーザー趣味'
        verbose_name_plural = 'ユーザー趣味'
        unique_together = [['user', 'product_category']]

    def __str__(self):
        return f"{self.user.user_name} - {self.product_category.category_name}"


# ────────────────────────────────────────────────────────────────────────────────
# 本人確認 / Identity Verification
# ────────────────────────────────────────────────────────────────────────────────

class IdentityVerificationStatus(models.Model):
    """
    本人確認ステータスマスター
    例: 未確認、確認済み、却下
    """
    identity_verification_status_id = models.AutoField(primary_key=True)
    status_name = models.CharField(max_length=50, unique=True)
    
    class Meta:
        db_table = 'M_IdentityVerificationStatus'
        verbose_name = '本人確認ステータス'
        verbose_name_plural = '本人確認ステータス'
    
    def __str__(self):
        return self.status_name


class IdentityVerification(models.Model):
    """
    本人確認テーブル
    ユーザーの本人確認申請と結果を管理
    申請時に個人情報を一時保存し、承認時にUserPersonalInfoに移行
    """
    identity_verification_id = models.AutoField(primary_key=True)

    identity_verification_status = models.ForeignKey(
        IdentityVerificationStatus,
        on_delete=models.PROTECT,
        db_column='identity_verification_status_id'
    )
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        db_column='user_id'
    )

    # 申請時の個人情報（一時保存用）
    last_name = models.CharField(max_length=50, null=True, blank=True, verbose_name='姓')
    first_name = models.CharField(max_length=50, null=True, blank=True, verbose_name='名')
    last_name_kana = models.CharField(max_length=50, null=True, blank=True, verbose_name='姓（カナ）')
    first_name_kana = models.CharField(max_length=50, null=True, blank=True, verbose_name='名（カナ）')
    birth_date = models.DateField(null=True, blank=True, verbose_name='生年月日')
    gender = models.IntegerField(
        choices=[(1, '男性'), (2, '女性'), (3, 'その他')],
        null=True, blank=True,
        verbose_name='性別'
    )

    rejection_datetime = models.DateTimeField(null=True, blank=True)
    approval_datetime = models.DateTimeField(null=True, blank=True)
    register_datetime = models.DateTimeField(auto_now_add=True)
    update_datetime = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'T_IdentityVerification'
        verbose_name = '本人確認'
        verbose_name_plural = '本人確認'
    
    def __str__(self):
        return f"{self.user.display_name} - {self.identity_verification_status}"


class IdentityVerificationImage(models.Model):
    """
    本人確認画像テーブル
    身分証明書の画像データを保存
    """
    identity_verification_image_id = models.AutoField(primary_key=True)
    
    identity_verification = models.ForeignKey(
        IdentityVerification,
        on_delete=models.CASCADE,
        related_name='images',
        db_column='identity_verification_id'
    )
    
    image_data = models.BinaryField()
    register_datetime = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'T_IdentityVerificationImage'
        verbose_name = '本人確認画像'
        verbose_name_plural = '本人確認画像'


# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║  2. ユーザー関係 / USER RELATIONSHIPS                                         ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

class Follow(models.Model):
    """
    フォローテーブル
    ユーザー間のフォロー関係を管理
    
    【unique_together の説明】
    同じユーザーを2回フォローできないように、
    (follower_user, followed_user) の組み合わせを一意にする
    """
    follow_id = models.AutoField(primary_key=True)
    
    follower_user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='following',
        db_column='follower_user_id'
    )
    followed_user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='followers',
        db_column='followed_user_id'
    )
    
    register_datetime = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'T_Follow'
        verbose_name = 'フォロー'
        verbose_name_plural = 'フォロー'
        unique_together = [['follower_user', 'followed_user']]
    
    def __str__(self):
        return f"{self.follower_user.display_name}が{self.followed_user.display_name}をフォロー"


class ListingNotification(models.Model):
    """
    出品通知購読テーブル
    特定ユーザーの新規出品を通知で受け取る設定
    """
    listing_notification_id = models.AutoField(primary_key=True)
    subscriber_user = models.ForeignKey(
        User, on_delete=models.CASCADE,
        related_name='listing_subscriptions',
        db_column='subscriber_user_id'
    )
    target_user = models.ForeignKey(
        User, on_delete=models.CASCADE,
        related_name='listing_subscribers',
        db_column='target_user_id'
    )
    register_datetime = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'T_ListingNotification'
        verbose_name = '出品通知購読'
        verbose_name_plural = '出品通知購読'
        unique_together = [['subscriber_user', 'target_user']]

    def __str__(self):
        return f"{self.subscriber_user.display_name}が{self.target_user.display_name}の出品を購読"


class Block(models.Model):
    """
    ブロックテーブル
    ユーザー間のブロック関係を管理
    """
    block_id = models.AutoField(primary_key=True)
    
    blocker_user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='blocking',
        db_column='blocker_user_id'
    )
    blocked_user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='blocked_by',
        db_column='blocked_user_id'
    )
    
    register_datetime = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'T_Block'
        verbose_name = 'ブロック'
        verbose_name_plural = 'ブロック'
        unique_together = [['blocker_user', 'blocked_user']]
    
    def __str__(self):
        return f"{self.blocker_user.display_name}が{self.blocked_user.display_name}をブロック"


class UserReview(models.Model):
    """
    ユーザー評価テーブル
    ユーザー間の評価とレビューを管理
    """
    user_review_id = models.AutoField(primary_key=True)
    
    reviewer_user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='reviews_given',
        db_column='reviewer_user_id'
    )
    reviewed_user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='reviews_received',
        db_column='reviewed_user_id'
    )
    rental_history = models.ForeignKey(
        'RentalHistory',
        on_delete=models.PROTECT,
        related_name='reviews',
        db_column='rental_history_id',
        null=True,
        blank=True
    )

    review_content = models.CharField(max_length=1000, null=True, blank=True)
    review_score = models.DecimalField(max_digits=3, decimal_places=2)
    register_datetime = models.DateTimeField(auto_now_add=True)
    update_datetime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'T_UserReview'
        verbose_name = 'ユーザー評価'
        verbose_name_plural = 'ユーザー評価'
        unique_together = [['reviewer_user', 'rental_history']]
    
    def __str__(self):
        return f"{self.reviewer_user.display_name} → {self.reviewed_user.display_name}: {self.review_score}"


# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║  3. 商品関連 / PRODUCT DOMAIN                                                 ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

class ProductCategory(models.Model):
    """
    商品カテゴリマスター（階層構造対応）
    例: 電化製品 > ノートパソコン
    
    【階層構造の説明】
    parent_product_category = Noneの場合、親カテゴリ（ルート）
    parent_product_category = 他のカテゴリの場合、子カテゴリ
    """
    product_category_id = models.AutoField(primary_key=True)
    
    parent_product_category = models.ForeignKey(
        'self',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='subcategories',
        db_column='parent_product_category_id'
    )
    
    category_name = models.CharField(max_length=100)
    
    class Meta:
        db_table = 'M_ProductCategory'
        verbose_name = '商品カテゴリ'
        verbose_name_plural = '商品カテゴリ'
    
    def __str__(self):
        return self.category_name


class ProductCategoryImage(models.Model):
    """
    商品カテゴリ画像テーブル
    カテゴリの代表画像を管理
    """
    product_category_image_id = models.AutoField(primary_key=True)
    product_category = models.OneToOneField(
        ProductCategory,
        on_delete=models.CASCADE,
        related_name='image',
        db_column='product_category_id'
    )
    image = models.ImageField(upload_to='category_images/', null=True, blank=True)
    register_datetime = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'T_ProductCategoryImage'
        verbose_name = '商品カテゴリ画像'
        verbose_name_plural = '商品カテゴリ画像'


class ProductCondition(models.Model):
    """
    商品状態マスター
    例: 新品、中古良好、使用感あり
    """
    product_condition_id = models.AutoField(primary_key=True)
    condition_name = models.CharField(max_length=50, unique=True)
    
    class Meta:
        db_table = 'M_ProductCondition'
        verbose_name = '商品状態'
        verbose_name_plural = '商品状態'
    
    def __str__(self):
        return self.condition_name


class ProductStatus(models.Model):
    """
    商品ステータスマスター
    例: 貸出可能、貸出中、メンテナンス中、非公開
    """
    product_status_id = models.AutoField(primary_key=True)
    status_name = models.CharField(max_length=50, unique=True)
    
    class Meta:
        db_table = 'M_ProductStatus'
        verbose_name = '商品ステータス'
        verbose_name_plural = '商品ステータス'
    
    def __str__(self):
        return self.status_name


class ShippingDays(models.Model):
    """
    発送日数マスター
    例: 1〜2日で発送、2〜3日で発送、4〜7日で発送
    """
    shipping_days_id = models.AutoField(primary_key=True)
    days_label = models.CharField(max_length=50, unique=True)  # 表示名: "1〜2日で発送"
    days_min = models.IntegerField()  # 最小日数
    days_max = models.IntegerField()  # 最大日数
    display_order = models.IntegerField(default=0)  # 表示順序

    class Meta:
        db_table = 'M_ShippingDays'
        verbose_name = '発送日数'
        verbose_name_plural = '発送日数'
        ordering = ['display_order', 'days_min']

    def __str__(self):
        return self.days_label


class ShippingBurden(models.Model):
    """
    発送料負担マスター
    例: 出品者負担、レンタル者負担
    """
    shipping_burden_id = models.AutoField(primary_key=True)
    burden_name = models.CharField(max_length=50, unique=True)

    class Meta:
        db_table = 'M_ShippingBurden'
        verbose_name = '発送料負担'
        verbose_name_plural = '発送料負担'

    def __str__(self):
        return self.burden_name


class Product(models.Model):
    """
    商品テーブル
    レンタル可能な商品を管理
    
    【on_delete の使い分け】
    - マスターデータ（ステータス、カテゴリなど）: PROTECT
    - オーナー（ユーザー）: CASCADE
    """
    product_id = models.AutoField(primary_key=True)
    product_name = models.CharField(max_length=200)
    product_description = models.CharField(max_length=2000, null=True, blank=True)
    
    # 外部キー: マスターデータ（全てPROTECT）
    shipping_days = models.ForeignKey(
        ShippingDays,
        on_delete=models.PROTECT,
        db_column='shipping_days_id',
        null=True,
        blank=True
    )
    shipping_burden = models.ForeignKey(
        ShippingBurden,
        on_delete=models.PROTECT,
        db_column='shipping_burden_id',
        null=True,
        blank=True
    )
    product_condition = models.ForeignKey(
        ProductCondition,
        on_delete=models.PROTECT,
        db_column='product_condition_id',
        null=True,
        blank=True
    )
    product_status = models.ForeignKey(
        ProductStatus,
        on_delete=models.PROTECT,
        db_column='product_status_id'
    )
    product_category = models.ForeignKey(
        ProductCategory,
        on_delete=models.PROTECT,
        db_column='product_category_id'
    )
    
    # レンタル情報
    rental_days = models.IntegerField()
    rental_fee = models.DecimalField(max_digits=10, decimal_places=2)
    contract_datetime = models.DateTimeField(null=True, blank=True)
    listing_stop_datetime = models.DateTimeField(null=True, blank=True)
    
    # 外部キー: オーナー（CASCADE）
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='products',
        db_column='user_id'
    )

    # 発送元住所（出品者の住所）
    shipping_address = models.ForeignKey(
        UserAddress,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='products_as_shipping',
        db_column='shipping_address_id'
    )

    # 発送元都道府県（住所から取得）
    shipping_prefecture = models.ForeignKey(
        Prefecture,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='products_as_shipping',
        db_column='shipping_prefecture_id'
    )

    register_datetime = models.DateTimeField(auto_now_add=True)
    update_datetime = models.DateTimeField(auto_now=True)
    delete_datetime = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = 'T_Product'
        verbose_name = '商品'
        verbose_name_plural = '商品'

    def __str__(self):
        return self.product_name

    @property
    def min_rental_plan(self):
        """最短日数のレンタルプランを取得"""
        return self.rental_plans.order_by('rental_days').first()


class ProductImage(models.Model):
    """
    商品画像テーブル
    商品の画像を管理（複数画像対応）

    【CASCADE の理由】
    商品が削除されたら、その画像も不要になるため
    """
    product_image_id = models.AutoField(primary_key=True)

    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        related_name='images',
        db_column='product_id'
    )

    image = models.ImageField(upload_to='product_images/')
    display_order = models.IntegerField(default=0)  # 表示順序（0が最初）
    register_datetime = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'T_ProductImage'
        verbose_name = '商品画像'
        verbose_name_plural = '商品画像'
        ordering = ['display_order', 'product_image_id']

    def __str__(self):
        return f"{self.product.product_name} - 画像 {self.display_order + 1}"


class ProductRentalPlan(models.Model):
    """
    商品レンタルプランテーブル
    1つの商品に対して複数のレンタル日数・金額を設定可能（1対多）
    """
    product_rental_plan_id = models.AutoField(primary_key=True)

    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        related_name='rental_plans',
        db_column='product_id'
    )

    rental_days = models.IntegerField()  # レンタル日数
    rental_fee = models.DecimalField(max_digits=10, decimal_places=0)  # レンタル金額
    register_datetime = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'T_ProductRentalPlan'
        verbose_name = '商品レンタルプラン'
        verbose_name_plural = '商品レンタルプラン'
        ordering = ['rental_days']

    def __str__(self):
        return f"{self.product.product_name} - {self.rental_days}日 ¥{self.rental_fee}"


class Bookmark(models.Model):
    """
    お気に入りテーブル
    ユーザーがお気に入り登録した商品を管理
    """
    bookmark_id = models.AutoField(primary_key=True)
    
    product = models.ForeignKey(
        Product, 
        on_delete=models.CASCADE, 
        db_column='product_id'
    )
    user = models.ForeignKey(
        User, 
        on_delete=models.CASCADE, 
        related_name='bookmarks', 
        db_column='user_id'
    )
    
    register_datetime = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'T_Bookmark'
        verbose_name = 'お気に入り'
        verbose_name_plural = 'お気に入り'
        unique_together = [['product', 'user']]
    
    def __str__(self):
        return f"{self.user.display_name} - {self.product.product_name}"


class BrowsingHistory(models.Model):
    """
    閲覧履歴テーブル
    ユーザーの商品閲覧履歴を記録
    """
    browsing_history_id = models.AutoField(primary_key=True)
    
    product = models.ForeignKey(
        Product, 
        on_delete=models.CASCADE, 
        db_column='product_id'
    )
    user = models.ForeignKey(
        User, 
        on_delete=models.CASCADE, 
        related_name='browsing_history', 
        db_column='user_id'
    )
    
    register_datetime = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'T_BrowsingHistory'
        verbose_name = '閲覧履歴'
        verbose_name_plural = '閲覧履歴'


# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║  4. レンタル関連 / RENTAL DOMAIN                                              ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

class RentalStatus(models.Model):
    """
    レンタルステータスマスター
    例: 予約中、貸出中、返却済み、キャンセル
    """
    rental_status_id = models.AutoField(primary_key=True)
    status_name = models.CharField(max_length=50, unique=True)
    
    class Meta:
        db_table = 'M_RentalStatus'
        verbose_name = 'レンタルステータス'
        verbose_name_plural = 'レンタルステータス'
    
    def __str__(self):
        return self.status_name


class RentalRequestStatus(models.Model):
    """
    レンタルリクエストステータスマスター
    例: 申請中、承認済み、却下、キャンセル
    """
    rental_request_status_id = models.AutoField(primary_key=True)
    status_name = models.CharField(max_length=50, unique=True)
    
    class Meta:
        db_table = 'M_RentalRequestStatus'
        verbose_name = 'レンタルリクエストステータス'
        verbose_name_plural = 'レンタルリクエストステータス'
    
    def __str__(self):
        return self.status_name


class ReturnReason(models.Model):
    """
    返却理由マスター
    例: 破損、紛失、期間延長希望
    """
    return_reason_id = models.AutoField(primary_key=True)
    return_reason_name = models.CharField(max_length=100, unique=True)
    
    class Meta:
        db_table = 'M_ReturnReason'
        verbose_name = '返却理由'
        verbose_name_plural = '返却理由'
    
    def __str__(self):
        return self.return_reason_name


class RentalRequest(models.Model):
    """
    レンタルリクエストテーブル
    レンタルの申請と承認プロセスを管理
    """
    rental_request_id = models.AutoField(primary_key=True)
    
    product = models.ForeignKey(
        Product, 
        on_delete=models.PROTECT, 
        db_column='product_id'
    )
    requester_user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='rental_requests_made',
        db_column='requester_user_id'
    )
    requested_user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='rental_requests_received',
        db_column='requested_user_id'
    )
    rental_request_status = models.ForeignKey(
        RentalRequestStatus,
        on_delete=models.PROTECT,
        db_column='rental_request_status_id'
    )
    product_rental_plan = models.ForeignKey(
        ProductRentalPlan,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name='rental_requests',
        db_column='product_rental_plan_id'
    )

    approval_datetime = models.DateTimeField(null=True, blank=True)
    rejection_datetime = models.DateTimeField(null=True, blank=True)
    register_datetime = models.DateTimeField(auto_now_add=True)
    update_datetime = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'T_RentalRequest'
        verbose_name = 'レンタルリクエスト'
        verbose_name_plural = 'レンタルリクエスト'


class RentalRequestReadType(models.Model):
    """
    レンタル申請既読タイプマスター
    1: 受け取った申請/承認待ち
    2: 受け取った申請/承認済み
    3: 送った申請/承認待ち
    4: 送った申請/承認済み
    """
    rental_request_read_type_id = models.AutoField(primary_key=True)
    type_name = models.CharField(max_length=50, unique=True)

    class Meta:
        db_table = 'M_RentalRequestReadType'
        verbose_name = 'レンタル申請既読タイプ'
        verbose_name_plural = 'レンタル申請既読タイプ'

    def __str__(self):
        return self.type_name


class RentalRequestRead(models.Model):
    """
    レンタル申請既読テーブル
    各ユーザーがどのタブでレンタル申請を既読したかを管理
    """
    rental_request_read_id = models.AutoField(primary_key=True)

    rental_request = models.ForeignKey(
        RentalRequest,
        on_delete=models.CASCADE,
        related_name='reads',
        db_column='rental_request_id'
    )
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        db_column='user_id'
    )
    rental_request_read_type = models.ForeignKey(
        RentalRequestReadType,
        on_delete=models.PROTECT,
        db_column='rental_request_read_type_id'
    )

    read_datetime = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'T_RentalRequestRead'
        verbose_name = 'レンタル申請既読'
        verbose_name_plural = 'レンタル申請既読'
        unique_together = [['rental_request', 'user', 'rental_request_read_type']]


class RentalHistory(models.Model):
    """
    レンタル履歴テーブル
    
    【重要: on_delete=PROTECT を使用】
    履歴データは監査、分析、トラブル対応に必要なため、
    関連するユーザーや商品が削除されても履歴は保持する必要がある
    → PROTECTを使用し、履歴がある場合は削除を防止
    """
    rental_history_id = models.AutoField(primary_key=True)
    
    # 外部キー: 全てPROTECT（履歴保護）
    product = models.ForeignKey(
        Product,
        on_delete=models.PROTECT,
        db_column='product_id'
    )
    lender_user = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        related_name='rentals_as_lender',
        db_column='lender_user_id'
    )
    renter_user = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        related_name='rentals_as_renter',
        db_column='renter_user_id'
    )
    rental_status = models.ForeignKey(
        RentalStatus,
        on_delete=models.PROTECT,
        db_column='rental_status_id'
    )

    # 購入者（借り手）の配送先住所
    renter_address = models.ForeignKey(
        UserAddress,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name='rental_histories_as_renter',
        db_column='renter_address_id'
    )

    shipping_completed_datetime = models.DateTimeField(null=True, blank=True)
    rental_start_datetime = models.DateTimeField(null=True, blank=True)
    rental_end_datetime = models.DateTimeField(null=True, blank=True)
    receipt_completed_datetime = models.DateTimeField(null=True, blank=True)

    # レンタル期間
    rental_days = models.IntegerField(null=True, blank=True)
    rental_deadline = models.DateTimeField(null=True, blank=True)
    return_shipping_deadline = models.DateTimeField(null=True, blank=True)

    # 発送追跡（貸主→借り手）
    shipping_tracking_number = models.CharField(max_length=50, null=True, blank=True)
    shipping_carrier_code = models.CharField(max_length=20, null=True, blank=True)

    # 返送追跡（借り手→貸主）
    return_tracking_number = models.CharField(max_length=50, null=True, blank=True)
    return_carrier_code = models.CharField(max_length=20, null=True, blank=True)

    # 超過通知済みフラグ（バッチ重複防止）
    overdue_notified_datetime = models.DateTimeField(null=True, blank=True)

    # クーポン適用
    user_coupon = models.ForeignKey(
        'UserCoupon',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='rental_histories',
        db_column='user_coupon_id',
        verbose_name='使用クーポン'
    )
    coupon_discount_amount = models.DecimalField(
        max_digits=10, decimal_places=0,
        null=True, blank=True,
        verbose_name='クーポン値引き額'
    )

    register_datetime = models.DateTimeField(auto_now_add=True)
    update_datetime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'T_RentalHistory'
        verbose_name = 'レンタル履歴'
        verbose_name_plural = 'レンタル履歴'
    
    def __str__(self):
        return f"{self.product.product_name} - {self.renter_user.display_name}"


class ReturnReasonHistory(models.Model):
    """
    返却理由履歴テーブル
    商品返却時の理由と詳細を記録
    """
    return_history_id = models.AutoField(primary_key=True)
    
    rental_history = models.ForeignKey(
        RentalHistory,
        on_delete=models.CASCADE,
        db_column='rental_history_id'
    )
    return_reason = models.ForeignKey(
        ReturnReason,
        on_delete=models.PROTECT,
        db_column='return_reason_id'
    )
    
    return_request_datetime = models.DateTimeField()
    return_completed_datetime = models.DateTimeField(null=True, blank=True)
    return_reason_detail = models.CharField(max_length=1000, null=True, blank=True)
    return_status_id = models.IntegerField(null=True, blank=True)
    register_datetime = models.DateTimeField(auto_now_add=True)
    update_datetime = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'T_ReturnReason'
        verbose_name = '返却理由履歴'
        verbose_name_plural = '返却理由履歴'


# ────────────────────────────────────────────────────────────────────────────────
# 取引中止 / Cancellation
# ────────────────────────────────────────────────────────────────────────────────

class CancellationReason(models.Model):
    """
    中止理由マスター
    例: 商品説明と実物が異なる、商品が届かない、商品が破損していた、相手と連絡が取れない、その他
    """
    cancellation_reason_id = models.AutoField(primary_key=True)
    reason_name = models.CharField(max_length=100, unique=True)

    class Meta:
        db_table = 'M_CancellationReason'
        verbose_name = '中止理由'
        verbose_name_plural = '中止理由'

    def __str__(self):
        return self.reason_name


class CancellationStatus(models.Model):
    """
    中止ステータスマスター
    1: 申請中
    2: 承認
    3: 却下
    """
    cancellation_status_id = models.AutoField(primary_key=True)
    status_name = models.CharField(max_length=50, unique=True)

    class Meta:
        db_table = 'M_CancellationStatus'
        verbose_name = '中止ステータス'
        verbose_name_plural = '中止ステータス'

    def __str__(self):
        return self.status_name


class CancellationRequest(models.Model):
    """
    取引中止申請テーブル
    取引中のトラブル時に運営へ中止を申請するレコード
    """
    cancellation_request_id = models.AutoField(primary_key=True)

    rental_history = models.ForeignKey(
        RentalHistory,
        on_delete=models.PROTECT,
        related_name='cancellation_requests',
        db_column='rental_history_id'
    )
    requester_user = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        related_name='cancellation_requests',
        db_column='requester_user_id'
    )
    cancellation_reason = models.ForeignKey(
        CancellationReason,
        on_delete=models.PROTECT,
        db_column='cancellation_reason_id'
    )
    cancellation_status = models.ForeignKey(
        CancellationStatus,
        on_delete=models.PROTECT,
        db_column='cancellation_status_id'
    )

    detail = models.CharField(max_length=1000, null=True, blank=True)
    admin_note = models.CharField(max_length=1000, null=True, blank=True)
    previous_rental_status_id = models.IntegerField()

    request_datetime = models.DateTimeField(auto_now_add=True)
    approval_datetime = models.DateTimeField(null=True, blank=True)
    rejection_datetime = models.DateTimeField(null=True, blank=True)
    register_datetime = models.DateTimeField(auto_now_add=True)
    update_datetime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'T_CancellationRequest'
        verbose_name = '取引中止申請'
        verbose_name_plural = '取引中止申請'

    def __str__(self):
        return f"中止申請 #{self.cancellation_request_id} - {self.rental_history}"


# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║  5. 通報・違反関連 / REPORT & VIOLATION DOMAIN                                ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

class ReportReason(models.Model):
    """
    通報理由マスター
    例: 不適切なコンテンツ、詐欺、規約違反
    """
    report_reason_id = models.AutoField(primary_key=True)
    report_reason_name = models.CharField(max_length=100, unique=True)
    
    class Meta:
        db_table = 'M_ReportReason'
        verbose_name = '通報理由'
        verbose_name_plural = '通報理由'
    
    def __str__(self):
        return self.report_reason_name


class Report(models.Model):
    """
    通報テーブル
    不適切なユーザーや商品の通報を管理
    """
    report_id = models.AutoField(primary_key=True)

    reporter_user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='reports_made',
        db_column='reporter_user_id'
    )
    reported_user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='reports_received',
        db_column='reported_user_id'
    )
    report_reason = models.ForeignKey(
        ReportReason,
        on_delete=models.PROTECT,
        db_column='report_reason_id'
    )
    
    report_detail = models.CharField(max_length=1000, null=True, blank=True)
    report_datetime = models.DateTimeField()
    register_datetime = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'T_Report'
        verbose_name = '通報'
        verbose_name_plural = '通報'


# ────────────────────────────────────────────────────────────────────────────────
# 違反 / Violation
# ────────────────────────────────────────────────────────────────────────────────

class ViolationReason(models.Model):
    """
    違反理由マスター
    例: スパム行為、支払い遅延、商品破損
    """
    violation_reason_id = models.AutoField(primary_key=True)
    violation_reason_name = models.CharField(max_length=100, unique=True)
    
    class Meta:
        db_table = 'M_ViolationReason'
        verbose_name = '違反理由'
        verbose_name_plural = '違反理由'
    
    def __str__(self):
        return self.violation_reason_name


class ViolationStatus(models.Model):
    """
    違反ステータスマスター
    例: 警告中、停止中、解除済み
    """
    violation_status_id = models.AutoField(primary_key=True)
    status_name = models.CharField(max_length=50, unique=True)
    
    class Meta:
        db_table = 'M_ViolationStatus'
        verbose_name = '違反ステータス'
        verbose_name_plural = '違反ステータス'
    
    def __str__(self):
        return self.status_name


class ViolationHistory(models.Model):
    """
    違反履歴テーブル
    ユーザーの規約違反履歴を管理
    """
    violation_history_id = models.AutoField(primary_key=True)
    
    violation_reason = models.ForeignKey(
        ViolationReason,
        on_delete=models.PROTECT,
        db_column='violation_reason_id'
    )
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='violations',
        db_column='user_id'
    )
    violation_status = models.ForeignKey(
        ViolationStatus,
        on_delete=models.PROTECT,
        db_column='violation_status_id'
    )
    
    violation_detail = models.CharField(max_length=1000, null=True, blank=True)
    violation_release_datetime = models.DateTimeField(null=True, blank=True)
    register_datetime = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'T_ViolationHistory'
        verbose_name = '違反履歴'
        verbose_name_plural = '違反履歴'


# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║  6. 決済・保険関連 / PAYMENT & INSURANCE DOMAIN                               ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

class PaymentType(models.Model):
    """
    支払い方法マスター
    例: クレジットカード、デビットカード、銀行振込、電子マネー
    """
    payment_type_id = models.AutoField(primary_key=True)
    payment_type_name = models.CharField(max_length=50, unique=True)
    
    class Meta:
        db_table = 'M_PaymentType'
        verbose_name = '支払い方法'
        verbose_name_plural = '支払い方法'
    
    def __str__(self):
        return self.payment_type_name


class PaymentInfo(models.Model):
    """
    支払い情報テーブル
    ユーザーの支払い方法を管理
    """
    payment_info_id = models.AutoField(primary_key=True)
    
    user = models.ForeignKey(
        User, 
        on_delete=models.CASCADE, 
        related_name='payment_info', 
        db_column='user_id'
    )
    payment_type = models.ForeignKey(
        PaymentType, 
        on_delete=models.PROTECT, 
        db_column='payment_type_id'
    )
    
    transfer_name = models.CharField(max_length=100, null=True, blank=True)
    card_token = models.CharField(max_length=255, null=True, blank=True)
    
    class Meta:
        db_table = 'T_PaymentInfo'
        verbose_name = '支払い情報'
        verbose_name_plural = '支払い情報'


class BankAccount(models.Model):
    """
    銀行口座テーブル
    ユーザーの振込・受取用銀行口座を管理

    【口座種別】
    - 1: 普通
    - 2: 当座
    """
    ACCOUNT_TYPE_CHOICES = [
        (1, '普通'),
        (2, '当座'),
    ]

    bank_account_id = models.AutoField(primary_key=True)

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='bank_accounts',
        db_column='user_id'
    )

    bank_name = models.CharField(max_length=100)  # 銀行名
    branch_name = models.CharField(max_length=100)  # 支店名
    account_type = models.IntegerField(choices=ACCOUNT_TYPE_CHOICES, default=1)  # 口座種別
    account_number = models.CharField(max_length=20)  # 口座番号
    account_holder = models.CharField(max_length=100)  # 口座名義（カナ）
    is_default = models.BooleanField(default=False)  # デフォルト口座フラグ
    register_datetime = models.DateTimeField(auto_now_add=True)
    update_datetime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'T_BankAccount'
        verbose_name = '銀行口座'
        verbose_name_plural = '銀行口座'

    def __str__(self):
        return f"{self.user.display_name} - {self.bank_name} {self.account_number[-4:]}"

    def save(self, *args, **kwargs):
        # デフォルト口座として保存する場合、他の口座のデフォルトを解除
        if self.is_default:
            BankAccount.objects.filter(user=self.user, is_default=True).exclude(pk=self.pk).update(is_default=False)
        super().save(*args, **kwargs)

    @property
    def masked_account_number(self):
        """口座番号をマスク表示（下4桁のみ表示）"""
        if len(self.account_number) > 4:
            return '*' * (len(self.account_number) - 4) + self.account_number[-4:]
        return self.account_number

    @property
    def account_type_display(self):
        """口座種別の表示名"""
        return dict(self.ACCOUNT_TYPE_CHOICES).get(self.account_type, '')


class CreditCard(models.Model):
    """
    クレジットカードテーブル
    購入者の支払い用クレジットカードを管理
    ※実際の決済連携はなし（モック）
    """
    credit_card_id = models.AutoField(primary_key=True)

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='credit_cards',
        db_column='user_id'
    )

    card_number_last4 = models.CharField(max_length=4)  # カード番号下4桁
    expiry_month = models.IntegerField()  # 有効期限（月）
    expiry_year = models.IntegerField()  # 有効期限（年）
    card_holder_name = models.CharField(max_length=100)  # カード名義人
    is_default = models.BooleanField(default=False)  # デフォルトカードフラグ
    register_datetime = models.DateTimeField(auto_now_add=True)
    update_datetime = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'T_CreditCard'
        verbose_name = 'クレジットカード'
        verbose_name_plural = 'クレジットカード'

    def __str__(self):
        return f"{self.user.display_name} - **** {self.card_number_last4}"

    def save(self, *args, **kwargs):
        # デフォルトカードとして保存する場合、他のカードのデフォルトを解除
        if self.is_default:
            CreditCard.objects.filter(user=self.user, is_default=True).exclude(pk=self.pk).update(is_default=False)
        super().save(*args, **kwargs)

    @property
    def masked_card_number(self):
        """カード番号をマスク表示（**** **** **** 1234）"""
        return f"**** **** **** {self.card_number_last4}"

    @property
    def expiry_display(self):
        """有効期限の表示（MM/YY）"""
        return f"{self.expiry_month:02d}/{str(self.expiry_year)[-2:]}"


# ────────────────────────────────────────────────────────────────────────────────
# 保険 / Insurance
# ────────────────────────────────────────────────────────────────────────────────

class Insurance(models.Model):
    """
    保険マスター
    商品レンタル時の保険商品
    """
    insurance_id = models.AutoField(primary_key=True)
    insurance_name = models.CharField(max_length=100, null=True, blank=True)
    insurance_description = models.CharField(max_length=1000, null=True, blank=True)
    insurance_fee = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    coverage_limit = models.DecimalField(max_digits=10, decimal_places=0, default=50000)  # 補償上限金額

    class Meta:
        db_table = 'M_Insurance'
        verbose_name = '保険'
        verbose_name_plural = '保険'

    def __str__(self):
        return self.insurance_name or f'保険 {self.insurance_id}'


class InsuranceEnrollmentStatus(models.Model):
    """
    保険加入ステータスマスター
    1: 未加入
    2: 加入中
    3: 解約済み
    4: 解約予約
    """
    insurance_enrollment_status_id = models.AutoField(primary_key=True)
    status_name = models.CharField(max_length=50, unique=True)
    
    class Meta:
        db_table = 'M_InsuranceEnrollmentStatus'
        verbose_name = '保険加入ステータス'
        verbose_name_plural = '保険加入ステータス'
    
    def __str__(self):
        return self.status_name


class InsuranceEnrollment(models.Model):
    """
    保険加入テーブル
    ユーザーの保険加入状況を管理
    """
    insurance_enrollment_id = models.AutoField(primary_key=True)

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        db_column='user_id'
    )
    insurance = models.ForeignKey(
        Insurance,
        on_delete=models.PROTECT,
        db_column='insurance_id'
    )

    insurance_enrollment_status = models.ForeignKey(
        InsuranceEnrollmentStatus,
        on_delete=models.PROTECT,
        db_column='insurance_enrollment_status_id',
        default=2  # 加入中
    )

    insurance_start_datetime = models.DateTimeField()
    insurance_end_datetime = models.DateTimeField(null=True, blank=True)
    cancel_reason = models.CharField(max_length=500, null=True, blank=True)

    class Meta:
        db_table = 'T_InsuranceEnrollment'
        verbose_name = '保険加入'
        verbose_name_plural = '保険加入'


class InsuranceCoveragePeriod(models.Model):
    """
    補償残枠管理テーブル
    InsuranceEnrollment と一対一の関係を持ち、
    補償期間と使用済み金額を直接管理する
    """
    coverage_period_id = models.AutoField(primary_key=True)
    insurance_enrollment = models.OneToOneField(
        InsuranceEnrollment,
        on_delete=models.CASCADE,
        related_name='coverage_period',
        db_column='insurance_enrollment_id'
    )
    period_start_datetime = models.DateTimeField()
    period_end_datetime = models.DateTimeField()
    coverage_limit = models.DecimalField(max_digits=10, decimal_places=0)  # 補償上限
    used_amount = models.DecimalField(max_digits=10, decimal_places=0, default=0)  # 使用済み金額

    class Meta:
        db_table = 'T_InsuranceCoveragePeriod'
        verbose_name = '補償残枠管理'
        verbose_name_plural = '補償残枠管理'

    @property
    def remaining(self):
        """補償残枠 = 上限 - 使用済み"""
        return max(0, int(self.coverage_limit) - int(self.used_amount))

    def __str__(self):
        return f"補償期間 {self.period_start_datetime:%Y/%m/%d} 〜 {self.period_end_datetime:%Y/%m/%d} (残枠: ¥{self.remaining:,})"


# ────────────────────────────────────────────────────────────────────────────────
# 補償申請 / Insurance Claim
# ────────────────────────────────────────────────────────────────────────────────

class InsuranceClaimStatus(models.Model):
    """
    補償申請ステータスマスター
    1: 審査中
    2: 承認
    3: 却下
    """
    insurance_claim_status_id = models.AutoField(primary_key=True)
    status_name = models.CharField(max_length=50, unique=True)

    class Meta:
        db_table = 'M_InsuranceClaimStatus'
        verbose_name = '補償申請ステータス'
        verbose_name_plural = '補償申請ステータス'

    def __str__(self):
        return self.status_name


class InsuranceClaim(models.Model):
    """
    補償申請テーブル
    商品破損時の保険請求を管理
    """
    claim_id = models.AutoField(primary_key=True)

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        db_column='user_id'
    )

    rental_history = models.ForeignKey(
        RentalHistory,
        on_delete=models.PROTECT,
        db_column='rental_history_id',
        null=True,
        blank=True
    )

    product = models.ForeignKey(
        Product,
        on_delete=models.PROTECT,
        db_column='product_id'
    )

    insurance_claim_status = models.ForeignKey(
        InsuranceClaimStatus,
        on_delete=models.PROTECT,
        db_column='insurance_claim_status_id'
    )

    claim_description = models.TextField()  # 破損内容
    repair_cost = models.DecimalField(max_digits=10, decimal_places=0)  # 修理費用

    claim_datetime = models.DateTimeField(auto_now_add=True)
    approval_datetime = models.DateTimeField(null=True, blank=True)
    rejection_datetime = models.DateTimeField(null=True, blank=True)
    rejection_reason = models.CharField(max_length=500, null=True, blank=True)

    class Meta:
        db_table = 'T_InsuranceClaim'
        verbose_name = '補償申請'
        verbose_name_plural = '補償申請'

    def __str__(self):
        return f"{self.user.display_name} - {self.product.product_name} (¥{self.repair_cost})"


class InsuranceClaimImage(models.Model):
    """
    補償申請画像テーブル
    補償申請時の添付画像を管理

    【画像タイプ】
    - 1: 破損した商品の画像
    - 2: 修理費用の領収書
    - 3: 修理後の商品の画像
    """
    IMAGE_TYPE_CHOICES = [
        (1, '破損画像'),
        (2, '領収書'),
        (3, '修理後画像'),
    ]

    image_id = models.AutoField(primary_key=True)

    claim = models.ForeignKey(
        InsuranceClaim,
        on_delete=models.CASCADE,
        related_name='images',
        db_column='claim_id'
    )

    image = models.ImageField(upload_to='insurance_claims/')
    image_type = models.IntegerField(choices=IMAGE_TYPE_CHOICES)
    register_datetime = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'T_InsuranceClaimImage'
        verbose_name = '補償申請画像'
        verbose_name_plural = '補償申請画像'

    def __str__(self):
        return f"Claim {self.claim_id} - {self.get_image_type_display()}"


# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║  7. チャット・メッセージ関連 / CHAT & MESSAGE DOMAIN                           ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

class BoardCategory(models.Model):
    """掲示板カテゴリマスター"""
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100, unique=True, verbose_name='カテゴリ名')

    class Meta:
        db_table = 'M_BoardCategory'
        verbose_name = '掲示板カテゴリ'
        verbose_name_plural = '掲示板カテゴリ'
        
    def __str__(self):
        return self.name

class ChatRoomType(models.Model):
    """
    チャットルームタイプマスター
    例: 1対1、グループ、商品チャット、コミュニティチャット
    """
    chat_room_type_id = models.AutoField(primary_key=True)
    type_name = models.CharField(max_length=50, null=True, blank=True)
    
    class Meta:
        db_table = 'M_ChatRoomType'
        verbose_name = 'チャットルームタイプ'
        verbose_name_plural = 'チャットルームタイプ'
    
    def __str__(self):
        return self.type_name or f'タイプ {self.chat_room_type_id}'


class Community(models.Model):
    """
    コミュニティテーブル -> 掲示板として利用
    """
    community_id = models.AutoField(primary_key=True)
    
    # 掲示板のタイトル（旧 community_name）
    name = models.CharField(max_length=200, verbose_name='掲示板タイトル', null=True, blank=True)
    
    # 要求仕様に基づきフィールドを追加
    description = models.TextField(verbose_name='説明文', null=True, blank=True)
    
    category = models.ForeignKey(
        BoardCategory, 
        on_delete=models.SET_NULL, # カテゴリが削除されても掲示板は残す
        null=True,
        verbose_name='カテゴリ'
    )
    
    creator = models.ForeignKey(
        User, 
        on_delete=models.SET_NULL, # ユーザーが削除されても掲示板は残す
        null=True, 
        related_name='created_communities', 
        verbose_name='作成者'
    )
    
    created_at = models.DateTimeField(default=timezone.now, verbose_name='作成日時')
    
    class Meta:
        db_table = 'T_Community'
        verbose_name = 'コミュニティ（掲示板）'
        verbose_name_plural = 'コミュニティ（掲示板）'
    
    def __str__(self):
        return self.name or ''


class CommunityMember(models.Model):
    """
    掲示板メンバーテーブル
    """
    community = models.ForeignKey(
        Community,
        on_delete=models.CASCADE,
        related_name='members',
        verbose_name='掲示板',
    )
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='joined_communities',
        verbose_name='ユーザー',
    )
    joined_at = models.DateTimeField(auto_now_add=True, verbose_name='参加日時')

    class Meta:
        db_table = 'T_CommunityMember'
        unique_together = ('community', 'user')
        verbose_name = '掲示板メンバー'
        verbose_name_plural = '掲示板メンバー'

    def __str__(self):
        return f'{self.community} - {self.user}'


class ChatRoom(models.Model):
    """
    チャットルームテーブル
    ユーザー間、商品、コミュニティのチャットルームを管理
    """
    chat_room_id = models.AutoField(primary_key=True)
    
    chat_room_type = models.ForeignKey(
        ChatRoomType, 
        on_delete=models.PROTECT, 
        db_column='chat_room_type_id'
    )
    product = models.ForeignKey(
        Product, 
        on_delete=models.CASCADE, 
        null=True, 
        blank=True, 
        db_column='product_id'
    )
    community = models.ForeignKey(
        Community,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        db_column='community_id'
    )
    rental_history = models.ForeignKey(
        RentalHistory,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='chat_rooms',
        db_column='rental_history_id'
    )

    class Meta:
        db_table = 'T_ChatRoom'
        verbose_name = 'チャットルーム'
        verbose_name_plural = 'チャットルーム'


class ChatRoomParticipant(models.Model):
    """
    チャットルーム参加者テーブル
    各チャットルームの参加ユーザーを管理
    """
    chat_room_participant_id = models.AutoField(primary_key=True)
    
    chat_room = models.ForeignKey(
        ChatRoom, 
        on_delete=models.CASCADE, 
        db_column='chat_room_id'
    )
    user = models.ForeignKey(
        User, 
        on_delete=models.CASCADE, 
        db_column='user_id'
    )
    
    register_datetime = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'T_ChatRoomParticipant'
        verbose_name = 'チャットルーム参加者'
        verbose_name_plural = 'チャットルーム参加者'
        unique_together = [['chat_room', 'user']]


class Message(models.Model):
    """
    メッセージテーブル
    チャット内のメッセージを管理
    """
    message_id = models.AutoField(primary_key=True)
    
    chat_room = models.ForeignKey(
        ChatRoom, 
        on_delete=models.CASCADE, 
        related_name='messages', 
        db_column='chat_room_id'
    )
    user = models.ForeignKey(
        User, 
        on_delete=models.CASCADE, 
        db_column='user_id'
    )
    
    # 長い文章（説明文など）も保存できるようTextFieldに変更
    message_content = models.TextField(null=True, blank=True)
    
    # 添付機能のためのフィールドを追加
    product_link = models.ForeignKey(Product, on_delete=models.SET_NULL, null=True, blank=True, verbose_name='商品リンク')
    image = models.ImageField(upload_to='chat_images/', null=True, blank=True, verbose_name='添付画像')
    reply_to = models.ForeignKey('self', on_delete=models.SET_NULL, null=True, blank=True, related_name='replies', verbose_name='返信元メッセージ')

    register_datetime = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'T_Message'
        verbose_name = 'メッセージ'
        verbose_name_plural = 'メッセージ'


class MessageImage(models.Model):
    """
    メッセージ画像テーブル
    メッセージに添付された画像を管理
    """
    message_image_id = models.AutoField(primary_key=True)
    
    message = models.ForeignKey(
        Message, 
        on_delete=models.CASCADE, 
        related_name='images', 
        db_column='message_id'
    )
    
    image_data = models.BinaryField()
    register_datetime = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'T_MessageImage'
        verbose_name = 'メッセージ画像'
        verbose_name_plural = 'メッセージ画像'


class MessageReadStatus(models.Model):
    """
    メッセージ既読ステータスマスター
    例: 未読、既読
    """
    message_read_status_id = models.AutoField(primary_key=True)
    status_name = models.CharField(max_length=50, unique=True)
    
    class Meta:
        db_table = 'M_MessageReadStatus'
        verbose_name = 'メッセージ既読ステータス'
        verbose_name_plural = 'メッセージ既読ステータス'
    
    def __str__(self):
        return self.status_name


class MessageRead(models.Model):
    """
    メッセージ既読テーブル
    各ユーザーのメッセージ既読状態を管理
    """
    message_read_id = models.AutoField(primary_key=True)
    
    message = models.ForeignKey(
        Message, 
        on_delete=models.CASCADE, 
        db_column='message_id'
    )
    user = models.ForeignKey(
        User, 
        on_delete=models.CASCADE, 
        db_column='user_id'
    )
    message_read_status = models.ForeignKey(
        MessageReadStatus, 
        on_delete=models.PROTECT, 
        db_column='message_read_status_id'
    )
    
    read_datetime = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        db_table = 'T_MessageRead'
        verbose_name = 'メッセージ既読'
        verbose_name_plural = 'メッセージ既読'
        unique_together = [['message', 'user']]


# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║  8. 通知関連 / NOTIFICATION DOMAIN                                            ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

class NotificationType(models.Model):
    """
    通知タイプマスター
    例: システム通知、メッセージ通知、レンタル通知
    """
    notification_type_id = models.AutoField(primary_key=True)
    notification_type_name = models.CharField(max_length=50, unique=True)
    
    class Meta:
        db_table = 'M_NotificationType'
        verbose_name = '通知タイプ'
        verbose_name_plural = '通知タイプ'
    
    def __str__(self):
        return self.notification_type_name


class NotificationReadStatus(models.Model):
    """
    通知既読ステータスマスター
    例: 未読、既読
    """
    notification_read_status_id = models.AutoField(primary_key=True)
    status_name = models.CharField(max_length=50, unique=True)
    
    class Meta:
        db_table = 'M_NotificationReadStatus'
        verbose_name = '通知既読ステータス'
        verbose_name_plural = '通知既読ステータス'
    
    def __str__(self):
        return self.status_name


class TargetUserType(models.Model):
    """
    ターゲットユーザータイプマスター
    通知の対象ユーザータイプを管理
    """
    target_user_type_id = models.AutoField(primary_key=True)
    type_name = models.CharField(max_length=50, null=True, blank=True)
    
    class Meta:
        db_table = 'M_TargetUserType'
        verbose_name = 'ターゲットユーザータイプ'
        verbose_name_plural = 'ターゲットユーザータイプ'
    
    def __str__(self):
        return self.type_name or f'タイプ {self.target_user_type_id}'


class Notification(models.Model):
    """
    通知テーブル
    システムからユーザーへの通知を管理
    """
    notification_id = models.AutoField(primary_key=True)
    
    notification_type = models.ForeignKey(
        NotificationType, 
        on_delete=models.PROTECT, 
        db_column='notification_type_id'
    )
    
    notification_title = models.CharField(max_length=200)
    notification_detail = models.CharField(max_length=1000, null=True, blank=True)
    link_url = models.CharField(max_length=500, null=True, blank=True)
    
    class Meta:
        db_table = 'T_Notification'
        verbose_name = '通知'
        verbose_name_plural = '通知'


class NotificationRead(models.Model):
    """
    通知既読テーブル
    各ユーザーの通知既読状態を管理
    """
    notification_read_id = models.AutoField(primary_key=True)
    
    notification = models.ForeignKey(
        Notification, 
        on_delete=models.CASCADE, 
        db_column='notification_id'
    )
    user = models.ForeignKey(
        User, 
        on_delete=models.CASCADE, 
        db_column='user_id'
    )
    notification_read_status = models.ForeignKey(
        NotificationReadStatus,
        on_delete=models.PROTECT,
        db_column='notification_read_status_id'
    )
    
    read_datetime = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        db_table = 'T_NotificationRead'
        verbose_name = '通知既読'
        verbose_name_plural = '通知既読'
        unique_together = [['notification', 'user']]


class NotificationTargetUser(models.Model):
    """
    通知ターゲットユーザーテーブル
    通知の送信対象ユーザーを管理
    """
    notification_target_user_id = models.AutoField(primary_key=True)
    
    notification = models.ForeignKey(
        Notification, 
        on_delete=models.CASCADE, 
        db_column='notification_id'
    )
    user = models.ForeignKey(
        User, 
        on_delete=models.CASCADE, 
        db_column='user_id'
    )
    
    register_datetime = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'T_NotificationTargetUser'
        verbose_name = '通知ターゲットユーザー'
        verbose_name_plural = '通知ターゲットユーザー'
        unique_together = [['notification', 'user']]


# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                          9. Q&A                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

class QAStatus(models.Model):
    """Q&Aステータスマスター（受付中 / 解決済み / 期限切れ終了）"""
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50, verbose_name='ステータス名')

    class Meta:
        db_table = 'M_QAStatus'
        verbose_name = 'Q&Aステータス'
        verbose_name_plural = 'Q&Aステータス'

    def __str__(self):
        return self.name


class QACategory(models.Model):
    """Q&A専用カテゴリマスター"""
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100, unique=True, verbose_name='カテゴリ名')

    class Meta:
        db_table = 'M_QACategory'
        verbose_name = 'Q&Aカテゴリ'
        verbose_name_plural = 'Q&Aカテゴリ'

    def __str__(self):
        return self.name


class QAQuestion(models.Model):
    """Q&A質問テーブル"""
    question_id = models.AutoField(primary_key=True)
    user = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='qa_questions', verbose_name='質問者'
    )
    category = models.ForeignKey(
        QACategory, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='questions', verbose_name='カテゴリ'
    )
    title = models.CharField(max_length=200, verbose_name='タイトル')
    content = models.TextField(verbose_name='本文')
    status = models.ForeignKey(
        QAStatus, on_delete=models.PROTECT, default=1, verbose_name='ステータス'
    )
    expires_at = models.DateTimeField(verbose_name='回答受付期限')
    expiry_notified_datetime = models.DateTimeField(null=True, blank=True, verbose_name='期限前通知日時')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='作成日時')
    updated_at = models.DateTimeField(auto_now=True, verbose_name='更新日時')

    class Meta:
        db_table = 'T_QAQuestion'
        ordering = ['-created_at']
        verbose_name = 'Q&A質問'
        verbose_name_plural = 'Q&A質問'

    def __str__(self):
        return self.title


class QAAnswer(models.Model):
    """Q&A回答テーブル（parent_answer が NULL なら通常回答、値があれば返信）"""
    answer_id = models.AutoField(primary_key=True)
    question = models.ForeignKey(
        QAQuestion, on_delete=models.CASCADE, related_name='answers', verbose_name='質問'
    )
    user = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='qa_answers', verbose_name='回答者'
    )
    parent_answer = models.ForeignKey(
        'self', on_delete=models.CASCADE, null=True, blank=True,
        related_name='replies', verbose_name='親回答'
    )
    content = models.TextField(verbose_name='回答内容')
    is_best_answer = models.BooleanField(default=False, verbose_name='ベストアンサー')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='投稿日時')

    class Meta:
        db_table = 'T_QAAnswer'
        ordering = ['created_at']
        verbose_name = 'Q&A回答'
        verbose_name_plural = 'Q&A回答'

    def __str__(self):
        return f'Answer({self.answer_id}) for Q({self.question_id})'


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  9. Coupon (クーポン)                                               ║
# ╚══════════════════════════════════════════════════════════════════════╝

class Coupon(models.Model):
    """クーポンマスター"""
    coupon_id = models.AutoField(primary_key=True)
    coupon_name = models.CharField(max_length=200, verbose_name='クーポン名')
    discount_amount = models.DecimalField(max_digits=10, decimal_places=0, verbose_name='値引き額')
    expires_at = models.DateTimeField(verbose_name='有効期限')
    is_active = models.BooleanField(default=True, verbose_name='有効フラグ')
    abolished_datetime = models.DateTimeField(null=True, blank=True, verbose_name='廃止日時')
    register_datetime = models.DateTimeField(auto_now_add=True, verbose_name='登録日時')
    update_datetime = models.DateTimeField(auto_now=True, verbose_name='更新日時')

    class Meta:
        db_table = 'M_Coupon'
        verbose_name = 'クーポン'
        verbose_name_plural = 'クーポン'

    def __str__(self):
        return self.coupon_name


class CouponTargetCategory(models.Model):
    """クーポン対象カテゴリマスター"""
    id = models.AutoField(primary_key=True)
    coupon = models.ForeignKey(
        Coupon, on_delete=models.CASCADE,
        related_name='target_categories', db_column='coupon_id',
        verbose_name='クーポン'
    )
    product_category = models.ForeignKey(
        ProductCategory, on_delete=models.CASCADE,
        related_name='coupon_targets', db_column='product_category_id',
        verbose_name='対象カテゴリ'
    )

    class Meta:
        db_table = 'M_CouponTargetCategory'
        verbose_name = 'クーポン対象カテゴリ'
        verbose_name_plural = 'クーポン対象カテゴリ'
        unique_together = [['coupon', 'product_category']]

    def __str__(self):
        return f'{self.coupon.coupon_name} - {self.product_category.category_name}'


class UserCoupon(models.Model):
    """ユーザー所持クーポン"""
    user_coupon_id = models.AutoField(primary_key=True)
    user = models.ForeignKey(
        User, on_delete=models.CASCADE,
        related_name='user_coupons', db_column='user_id',
        verbose_name='ユーザー'
    )
    coupon = models.ForeignKey(
        Coupon, on_delete=models.CASCADE,
        related_name='user_coupons', db_column='coupon_id',
        verbose_name='クーポン'
    )
    is_possessed = models.BooleanField(default=True, verbose_name='所持フラグ')
    used_datetime = models.DateTimeField(null=True, blank=True, verbose_name='使用日時')
    register_datetime = models.DateTimeField(auto_now_add=True, verbose_name='登録日時')
    update_datetime = models.DateTimeField(auto_now=True, verbose_name='更新日時')

    class Meta:
        db_table = 'T_UserCoupon'
        verbose_name = 'ユーザー所持クーポン'
        verbose_name_plural = 'ユーザー所持クーポン'

    def __str__(self):
        return f'{self.user.display_name} - {self.coupon.coupon_name}'


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  10. Quest (クエスト)                                               ║
# ╚══════════════════════════════════════════════════════════════════════╝

class Quest(models.Model):
    """
    クエストマスター
    ユーザーがミッションを達成すると報酬（クーポン）を獲得できる
    product_category が null の場合はチュートリアルクエスト
    """
    DIFFICULTY_CHOICES = [
        (0, 'チュートリアル'),
        (1, '初級'),
        (2, '中級'),
        (3, '上級'),
    ]

    quest_id = models.AutoField(primary_key=True)
    product_category = models.ForeignKey(
        ProductCategory,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='quests',
        db_column='product_category_id',
        verbose_name='商品カテゴリ'
    )
    quest_name = models.CharField(max_length=200, verbose_name='クエスト名')
    quest_description = models.CharField(max_length=500, verbose_name='クエスト説明')
    difficulty = models.IntegerField(choices=DIFFICULTY_CHOICES, default=0, verbose_name='難易度')
    reward_coupon = models.ForeignKey(
        Coupon,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='quests',
        db_column='reward_coupon_id',
        verbose_name='報酬クーポン'
    )
    display_order = models.IntegerField(default=0, verbose_name='表示順')
    is_active = models.BooleanField(default=True, verbose_name='有効フラグ')
    expires_at = models.DateTimeField(null=True, blank=True, verbose_name='有効期限')
    register_datetime = models.DateTimeField(auto_now_add=True, verbose_name='登録日時')
    update_datetime = models.DateTimeField(auto_now=True, verbose_name='更新日時')

    class Meta:
        db_table = 'M_Quest'
        verbose_name = 'クエスト'
        verbose_name_plural = 'クエスト'
        ordering = ['display_order', 'quest_id']

    def __str__(self):
        return self.quest_name


class QuestMission(models.Model):
    """
    クエストミッションマスター
    各クエストに紐づくミッション（達成条件）を定義
    """
    quest_mission_id = models.AutoField(primary_key=True)
    quest = models.ForeignKey(
        Quest,
        on_delete=models.CASCADE,
        related_name='missions',
        db_column='quest_id',
        verbose_name='クエスト'
    )
    mission_name = models.CharField(max_length=200, verbose_name='ミッション名')
    mission_description = models.CharField(max_length=500, blank=True, default='', verbose_name='ミッション説明')
    condition_type = models.CharField(max_length=50, verbose_name='条件種別')
    condition_params = models.JSONField(default=dict, verbose_name='条件パラメータ')
    display_order = models.IntegerField(default=0, verbose_name='表示順')

    class Meta:
        db_table = 'M_QuestMission'
        verbose_name = 'クエストミッション'
        verbose_name_plural = 'クエストミッション'
        ordering = ['display_order', 'quest_mission_id']

    def __str__(self):
        return f'{self.quest.quest_name} - {self.mission_name}'


class UserCompletedQuest(models.Model):
    """
    ユーザークエスト完了テーブル
    ユーザーが全ミッションを達成し報酬を受け取った記録
    """
    user_completed_quest_id = models.AutoField(primary_key=True)
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='completed_quests',
        db_column='user_id',
        verbose_name='ユーザー'
    )
    quest = models.ForeignKey(
        Quest,
        on_delete=models.CASCADE,
        related_name='completions',
        db_column='quest_id',
        verbose_name='クエスト'
    )
    completed_datetime = models.DateTimeField(verbose_name='完了日時')
    reward_claimed = models.BooleanField(default=False, verbose_name='報酬受取済み')
    reward_claimed_datetime = models.DateTimeField(null=True, blank=True, verbose_name='報酬受取日時')
    register_datetime = models.DateTimeField(auto_now_add=True, verbose_name='登録日時')

    class Meta:
        db_table = 'T_UserCompletedQuest'
        verbose_name = 'ユーザークエスト完了'
        verbose_name_plural = 'ユーザークエスト完了'
        unique_together = [['user', 'quest']]

    def __str__(self):
        return f'{self.user.display_name} - {self.quest.quest_name}'


# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║  補足説明 / ADDITIONAL NOTES                                                  ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

"""
【on_delete の選択基準】

1. models.CASCADE
   使用場面: 親がなければ子も不要な場合
   例: 
   - User → UserAddress（ユーザー削除 → 住所も削除）
   - Product → ProductImage（商品削除 → 画像も削除）
   - ChatRoom → Message（ルーム削除 → メッセージも削除）

2. models.PROTECT
   使用場面: 重要なデータ、削除してはいけないデータ
   例:
   - マスターデータ全般（Status → Product など）
   - 履歴データ（User → RentalHistory など）
   - 監査が必要なデータ

3. models.SET_NULL
   使用場面: 参照は残すが親は削除したい
   注意: null=True が必要
   例:
   - User → Article（ユーザー削除後も記事は残す）

【db_table の必要性】

指定しない場合: 'appname_modelname' という名前になる
指定する場合: 正確に指定した名前になる

例:
class User(models.Model):
    class Meta:
        db_table = 'T_User'  # テーブル名は正確に「T_User」

【related_name の使い方】

user.products.all()  # ユーザーの全商品
user.addresses.all()  # ユーザーの全住所  
user.following.all()  # フォロー中のユーザー
user.followers.all()  # フォロワー一覧


【テーブル一覧 / TABLE INDEX】

┌─────────────────────────────────────────────────────────────────────────────┐
│ DOMAIN                    │ MASTER (M_)           │ TRANSACTION (T_)        │
├─────────────────────────────────────────────────────────────────────────────┤
│ 1. User                   │ UserStatus            │ User                    │
│                           │ IdentityVerification- │ UserAddress             │
│                           │   Status              │ IdentityVerification    │
│                           │                       │ IdentityVerificationImg │
├─────────────────────────────────────────────────────────────────────────────┤
│ 2. User Relations         │ -                     │ Follow                  │
│                           │                       │ Block                   │
│                           │                       │ UserReview              │
├─────────────────────────────────────────────────────────────────────────────┤
│ 3. Product                │ ProductCategory       │ Product                 │
│                           │ ProductCondition      │ Bookmark                │
│                           │ ProductStatus         │ BrowsingHistory         │
│                           │ ShippingMethod        │                         │
├─────────────────────────────────────────────────────────────────────────────┤
│ 4. Rental                 │ RentalStatus          │ RentalRequest           │
│                           │ RentalRequestStatus   │ RentalHistory           │
│                           │ ReturnReason          │ ReturnReasonHistory     │
├─────────────────────────────────────────────────────────────────────────────┤
│ 5. Report & Violation     │ ReportReason          │ Report                  │
│                           │ ViolationReason       │ ViolationHistory        │
│                           │ ViolationStatus       │                         │
├─────────────────────────────────────────────────────────────────────────────┤
│ 6. Payment & Insurance    │ PaymentType           │ PaymentInfo             │
│                           │ Insurance             │ InsuranceEnrollment     │
│                           │ InsuranceEnrollment-  │                         │
│                           │   Status              │                         │
├─────────────────────────────────────────────────────────────────────────────┤
│ 7. Chat & Message         │ ChatRoomType          │ Community               │
│                           │ MessageReadStatus     │ ChatRoom                │
│                           │                       │ ChatRoomParticipant     │
│                           │                       │ Message                 │
│                           │                       │ MessageImage            │
│                           │                       │ MessageRead             │
├─────────────────────────────────────────────────────────────────────────────┤
│ 8. Notification           │ NotificationType      │ Notification            │
│                           │ NotificationReadStatus│ NotificationRead        │
│                           │ TargetUserType        │ NotificationTargetUser  │
└─────────────────────────────────────────────────────────────────────────────┘

Total: 21 Master Tables + 24 Transaction Tables = 45 Tables
"""