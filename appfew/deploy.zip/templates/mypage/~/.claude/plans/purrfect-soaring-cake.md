﻿# クエスト機能 実装計画

## Context

MONOTALにクエスト機能を追加する。ユーザーがミッションを達成すると報酬（クーポン）を獲得できる。
- **チュートリアルクエスト**: サービスの基本的な使い方を学ぶ（カテゴリ非依存）
- **商品カテゴリ別クエスト**: 各ProductCategory（ファッション、電子機器等）ごとに初級・中級・上級クエストを用意。そのカテゴリの商品を出品・レンタル・レビュー・ブックマーク等するミッションで構成

---

## 1. テーブル設計（3テーブル）

M_QuestCategoryは不要。Quest自体がProductCategoryへのFKを持つ設計。

### M_Quest（クエストマスター）
| カラム | 型 | 説明 |
|--------|-----|------|
| quest_id | AutoField PK | |
| product_category | FK → M_ProductCategory | SET_NULL, nullable。null=チュートリアル |
| quest_name | CharField(200) | 例: 「ファッション入門」 |
| quest_description | CharField(500) | |
| difficulty | IntegerField | 0=チュートリアル, 1=初級, 2=中級, 3=上級 |
| reward_coupon | FK → M_Coupon | SET_NULL, nullable |
| display_order | IntegerField default=0 | |
| is_active | BooleanField default=True | |
| register_datetime | auto_now_add | |
| update_datetime | auto_now | |
| db_table | `M_Quest` | |

### M_QuestMission（クエストミッションマスター）
| カラム | 型 | 説明 |
|--------|-----|------|
| quest_mission_id | AutoField PK | |
| quest | FK → M_Quest | CASCADE |
| mission_name | CharField(200) | |
| mission_description | CharField(500) | |
| condition_type | CharField(50) | チェック関数の種別キー |
| condition_params | JSONField default=dict | `{"count": 3}` 等 |
| display_order | IntegerField default=0 | |
| db_table | `M_QuestMission` | |

### T_UserCompletedQuest（ユーザークエスト完了）
| カラム | 型 | 説明 |
|--------|-----|------|
| user_completed_quest_id | AutoField PK | |
| user | FK → T_User | CASCADE |
| quest | FK → M_Quest | CASCADE |
| completed_datetime | DateTimeField | |
| reward_claimed | BooleanField default=False | |
| reward_claimed_datetime | DateTimeField nullable | |
| register_datetime | auto_now_add | |
| unique_together | [user, quest] | |
| db_table | `T_UserCompletedQuest` | |

> ミッション進捗はリアルタイムにDB照会して判定する（別テーブル不要）

---

## 2. ミッション条件チェック仕様

`_check_mission(user, condition_type, condition_params, product_category=None)` 関数。
カテゴリ別クエストでは `quest.product_category` を渡し、**そのカテゴリ＋子孫カテゴリ**の商品に絞り込む。

カテゴリ絞り込み対応の `_get_descendant_category_ids(category)` ヘルパーで階層構造に対応。

| condition_type | 判定内容 | カテゴリ絞り込み | params例 |
|---------------|----------|:---:|---------|
| `identity_verified` | user_status_id == 2 | - | `{}` |
| `profile_image_set` | user_image 設定済み | - | `{}` |
| `bio_set` | bio が空でない | - | `{}` |
| `hobby_registered` | UserHobby 1件以上 | - | `{}` |
| `address_registered` | UserAddress 1件以上 | - | `{}` |
| `bank_account_registered` | BankAccount 1件以上 | - | `{}` |
| `credit_card_registered` | CreditCard 1件以上 | - | `{}` |
| `insurance_enrolled` | InsuranceEnrollment 加入中 | - | `{}` |
| `follow_count` | Follow数 >= count | - | `{"count": 1}` |
| `product_listed` | Product出品数 >= count | **対応** | `{"count": 1}` |
| `bookmark_count` | Bookmark数 >= count | **対応** | `{"count": 3}` |
| `browsing_history_count` | 閲覧履歴数 >= count | **対応** | `{"count": 5}` |
| `rental_completed_renter` | レンタル完了数(借り手) >= count | **対応** | `{"count": 1}` |
| `rental_completed_lender` | レンタル完了数(貸し手) >= count | **対応** | `{"count": 1}` |
| `review_written` | レビュー投稿数 >= count | **対応** | `{"count": 1}` |
| `qa_question_posted` | Q&A質問投稿数 >= count | - | `{"count": 1}` |
| `qa_answer_posted` | Q&A回答投稿数 >= count | - | `{"count": 1}` |
| `qa_best_answer` | ベストアンサー獲得数 >= count | - | `{"count": 1}` |
| `board_created` | 掲示板作成数 >= count | - | `{"count": 1}` |
| `board_post_count` | 掲示板投稿数 >= count | - | `{"count": 5}` |
| `coupon_used` | クーポン使用数 >= count | - | `{"count": 1}` |

**カテゴリ絞り込み対応のcondition_type**: `product_listed`, `bookmark_count`, `browsing_history_count`, `rental_completed_renter`, `rental_completed_lender`, `review_written` — これらはProduct経由でcategoryをフィルタリングする。クエストにproduct_categoryが設定されている場合のみ自動適用。

---

## 3. クエスト内容（初期データ）

### チュートリアル（difficulty=0, product_category=null）

**Q1: はじめてのMONOTAL**（報酬: 200円OFF, 全カテゴリ対象, 30日有効）
- プロフィール画像を設定しよう (`profile_image_set`)
- 自己紹介を書こう (`bio_set`)
- 趣味を登録しよう (`hobby_registered`)
- 商品を3つ閲覧しよう (`browsing_history_count`, count:3)
- 商品を1つブックマークしよう (`bookmark_count`, count:1)

**Q2: 本人確認を完了しよう**（報酬: 500円OFF, 全カテゴリ対象, 30日有効）
- 本人確認を完了する (`identity_verified`)
- 住所を登録する (`address_registered`)
- 銀行口座を登録する (`bank_account_registered`)
- クレジットカードを登録する (`credit_card_registered`)

**Q3: コミュニティに参加しよう**（報酬: 300円OFF, 全カテゴリ対象, 30日有効）
- ユーザーを1人フォローしよう (`follow_count`, count:1)
- Q&Aで質問を投稿しよう (`qa_question_posted`, count:1)
- 掲示板で発言しよう (`board_post_count`, count:1)

### 各商品カテゴリ別クエスト（ProductCategoryごとに自動生成）

seed_questsコマンドが、**全ルートカテゴリ**（parent=null）について以下3クエストを自動生成。

**初級: ○○入門**（報酬: 300円OFF, 該当カテゴリ対象, 30日有効）
- ○○の商品を5つ閲覧しよう (`browsing_history_count`, count:5)
- ○○の商品を1つブックマークしよう (`bookmark_count`, count:1)
- ○○の商品を1つ出品しよう (`product_listed`, count:1)
- ○○の商品を1回レンタルしよう (`rental_completed_renter`, count:1)

**中級: ○○マスター**（報酬: 500円OFF, 該当カテゴリ対象, 30日有効）
- ○○の商品を3つ出品しよう (`product_listed`, count:3)
- ○○の商品を3回レンタルしよう (`rental_completed_renter`, count:3)
- ○○のレンタルを3回完了しよう（貸し手）(`rental_completed_lender`, count:3)
- ○○のレンタルに対してレビューを3件書こう (`review_written`, count:3)

**上級: ○○の達人**（報酬: 1000円OFF, 該当カテゴリ対象, 30日有効）
- ○○の商品を5つ出品しよう (`product_listed`, count:5)
- ○○の商品を5回レンタルしよう (`rental_completed_renter`, count:5)
- ○○のレンタルを5回完了しよう（貸し手）(`rental_completed_lender`, count:5)
- ○○のレンタルに対してレビューを5件書こう (`review_written`, count:5)

> ○○ = カテゴリ名（ファッション, 電子機器等）。seed_questsが動的に生成。

---

## 4. 実装ファイルと変更内容

### `appfew/monotal/models.py`（3モデル追加）
- `Quest`, `QuestMission`, `UserCompletedQuest`
- クーポンセクションの後、ADDITIONAL NOTESの前に追加

### `appfew/monotal/admin.py`（3モデル登録）
- `admin.site.register(Quest)`, `QuestMission`, `UserCompletedQuest`

### `appfew/monotal/views.py`（2ビュー + 2ヘルパー追加）
- `_get_descendant_category_ids(category)` — カテゴリ階層を辿って全子孫IDを取得
- `_check_mission(user, condition_type, condition_params, product_category=None)` — ミッション判定
- `MyPageQuestListView(LoginRequiredMixin, View)` — GET: クエスト一覧表示
  - チュートリアルとカテゴリ別にグループ分けして表示
  - 各ミッションの達成状況をリアルタイム判定
  - `current_page = 'quest_list'`
- `QuestClaimRewardView(LoginRequiredMixin, View)` — POST(AJAX): 報酬受取

### `appfew/monotal/urls.py`（2パス追加）
- `path('mypage/quests/', views.mypage_quest_list, name='mypage_quest_list')`
- `path('mypage/quests/<int:quest_id>/claim/', views.quest_claim_reward, name='quest_claim_reward')`

### `appfew/templates/mypage/quest_list.html`（新規）
- base.html extends, _sidebar.html include
- チュートリアルセクション + カテゴリ別アコーディオン
- 各クエスト: 難易度バッジ、プログレスバー、ミッション一覧（✓/○）、報酬額表示
- 「報酬を受け取る」ボタン（AJAX） / 「達成済み✓」表示

### `appfew/templates/mypage/_sidebar.html`（修正）
- 「所持クーポン」の下に「クエスト」リンク追加（`lucide:trophy`アイコン、`quest_list`アクティブ状態）

### `appfew/monotal/management/commands/seed_quests.py`（新規）
- チュートリアル3クエスト + ルートカテゴリ別3クエスト（初級/中級/上級）を自動生成
- 報酬用クーポンも同時作成（Coupon + 対象カテゴリ設定）

### マイグレーション
- `makemigrations` → `migrate`

---

## 5. 報酬受取フロー

1. クエストページ表示 → 各ミッションをリアルタイムチェック → 達成状況を表示
2. 全ミッション達成 → 「報酬を受け取る」ボタン有効化
3. ボタンクリック → AJAX POST → `QuestClaimRewardView`
4. サーバーで再度全ミッション達成確認（不正防止）
5. `T_UserCompletedQuest` 作成 + `UserCoupon` 作成（クーポン付与）
6. JSON成功レスポンス → UIを「達成済み」に更新

---

## 6. 検証方法

1. マイグレーション → テーブル作成確認
2. `python manage.py seed_quests` → 初期データ投入
3. マイページサイドバーに「クエスト」表示確認
4. クエストページ → チュートリアル＋カテゴリ別クエスト一覧表示確認
5. ミッション条件を満たす操作実行 → チェックマーク反映確認
6. 全ミッション達成 → 「報酬を受け取る」→ 所持クーポンページでクーポン付与確認
